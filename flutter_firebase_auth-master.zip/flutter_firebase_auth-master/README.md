
# Firebase Auth (Google) con Provider

![Firebase Auth y Provider](https://github.com/manudevcode/flutter_firebase_auth/blob/master/image/Web%201920%20%E2%80%93%201.png?raw=true)

Crea tu primer inicio de sesión con Google en Firebase Auth y Provider desde CERO!!!
[Video Tutorial](https://youtu.be/XidN4qBZLuI)

## Comenzar

Para que puedas ejecutar sin problemas este proyecto necesitas: 

- [Tener instalado Flutter](https://flutter.dev/docs/get-started/install)
- [La versión más reciente de VS Code para mas comodidad](https://code.visualstudio.com/)
- [Crear un proyecto en Firebase y agregar el GoogleServices.json](https://firebase.google.com/)
- Instalar las dependencias faltantes con el comando ```packages get```
